# Fluxo DevOps — Atividade 04: UniEventos

## Objetivo

Transformar a ideia do gerenciamento de eventos universitários em um produto digital que possa evoluir com versionamento, testes, integração, publicação e monitoramento.

## Repositório e organização Git

- `main`: versão estável.
- `develop`: integração de alterações.
- `feature/*`: funcionalidades novas.
- `fix/*`: correções de bugs.
- Fluxo recomendado: `feature/*` → `develop` → testes/revisão → `main` → deploy.
- Padrões de commit: `feat:`, `fix:`, `docs:`, `test:`, `refactor:`, `style:`.

### Exemplo de commits desta entrega

```text
fix: exibir confirmacao e historico de inscricoes
feat: ampliar eventos e capacidade de participantes
feat: permitir gerenciar presencas e vagas
style: aprimorar experiencia desktop e mobile
test: cobrir inscricao perfil painel e responsividade
docs: atualizar limitacoes do prototipo
```

## Backlog e evolução

| Recurso | Status da versão 2.0 | Evolução necessária |
|---|---|---|
| Inicial, catálogo, filtros, detalhes | Demonstrativo funcional | Alimentação a partir de API |
| Login/cadastro | Perfil de demonstração local | Autenticação segura, confirmação de e-mail, perfis |
| Inscrições e confirmação | Funcionais **no mesmo navegador** | Banco de dados e inscrição atômica |
| Minhas Inscrições | Comprovantes e histórico locais | Sincronização por conta real |
| Painel do organizador | Vagas, criação, presença, CSV | Autorização e permissões reais |
| Presença e certificados | Simulação e impressão demonstrativa | QR seguro e certificado validável |
| Notificações | Toasts e comprovante visual | E-mail/Push por backend |
| Segurança | Escapamento de HTML, validações de formulário | API, RLS, rate limit e auditoria |
| Testes e responsividade | Testes automatizados e widths 320–1920 px | E2E com backend e CI |
| Deploy | Arquivos estáticos prontos para Netlify | Pipeline automático GitHub→Netlify |

## Processo de desenvolvimento

1. Priorizar tarefas e requisitos identificados com a professora.
2. Criar branch para cada melhoria.
3. Desenvolver, revisar e fazer commits convencionais.
4. Integrar em `develop`.
5. Executar testes automatizados e revisão visual.
6. Integrar em `main` e publicar na Netlify.
7. Monitorar disponibilidade, console de erros e falhas de deploy.

## Testes realizados na v2

- Home e catálogo: 14 eventos e 6 categorias.
- Pesquisa por nome, categoria, formato e navegação.
- Identificação demonstrativa + inscrição + código/comprovante.
- Recuperação de inscrição ao recarregar, sair e entrar com mesmo e-mail no mesmo navegador.
- Exibição do status confirmado na página do evento.
- Edição da capacidade e criação de evento com 8.500 vagas.
- Busca de participante e check-in manual.
- Cancelamento da inscrição.
- Versão mobile, menu e ausência de rolagem horizontal.
- Sem erros de JavaScript nos fluxos testados.

**Atenção:** nenhum teste foi feito com backend porque ele ainda não existe. Os números de participantes iniciais são fictícios.

## Próximas melhorias da sprint

- Supabase Auth + PostgreSQL (ou solução equivalente).
- Registro único por evento e usuário, em transação.
- Disponibilidade de vagas global e sincronizada.
- Permissões distintas para aluno e organizador.
- Testes E2E de banco/API, controle de segurança e acessibilidade.

## Monitoramento

Após cada deploy, abrir no celular e computador, conferir inicialização, login de demonstração, registro, painel e console. Para defeitos: criar `fix/*`, revisar em `develop`, testar, integrar em `main` e republicar.
