# Roteiro para apresentar o UniEventos 3.0

**Acesso para a aula:** `leonardo@unieventos.demo` / `Campus2026!`

## Demonstração em 3–4 minutos

| Etapa | Faça isto | Fale isto, com suas palavras |
|---|---|---|
| 1. Início | Abra a página inicial | “O UniEventos centraliza os eventos da universidade e facilita a descoberta de oportunidades.” |
| 2. Explorar | Clique em **Explorar eventos**, digite “Python” e limpe a busca | “O estudante pesquisa e filtra os eventos sem precisar navegar por vários lugares.” |
| 3. Detalhes | Clique em **Semana de Tecnologia** ou **Hackathon** | “Cada evento mostra vagas, local, data, organização e o botão de inscrição.” |
| 4. Login | Clique em **Entrar**; preencha e-mail/senha | “Criamos uma conta de teste com algumas inscrições prontas para mostrar o sistema funcionando.” |
| 5. Aluno | Na tela **Minhas inscrições**, abra um comprovante | “A inscrição aparece no histórico, gera um código e mantém o status visível.” |
| 6. Nova inscrição | Abra **Hackathon**, clique **Garantir minha vaga** e volte ao histórico | “Uma nova inscrição aparece imediatamente na área do participante.” |
| 7. Organizador | Clique em **Organizador** → **Participantes** (Hackathon) | “O organizador enxerga a lista e pode pesquisar o participante e registrar presença.” |
| 8. Capacidade | Volte → clique **Vagas** | “Também é possível aumentar ou ajustar a capacidade do evento.” |

**Atalho:** o botão **✦ Apresentar** faz uma visita guiada, passando por sete telas, e deixa uma frase curta na tela para orientar a explicação.

## Dicas para o dia

- Se quiser mostrar **uma inscrição nova**, use o Hackathon: as três inscrições iniciais são Semana de Tecnologia, Feira de Carreiras e Workshop Python.
- Caso tenha inscrito o Hackathon anteriormente no mesmo navegador, **não o cadastre novamente**: abra outro evento não inscrito.
- Em **Minhas inscrições**, clique no nome do evento ou no botão **Comprovante** para mostrar o código de confirmação.
- Para mostrar a presença e o certificado, o organizador pode confirmar uma inscrição local e, depois, o aluno encontra o botão **Certificado** no histórico.
- O protótipo funciona em um único navegador: **números de lotação e perfis de exemplo são fictícios**, e uma inscrição feita por um computador não aparecerá em outro.
- Tenha a tela da Netlify aberta e os dados de login anotados, sem depender do preenchimento automático.

## Perguntas que a professora pode fazer

**“O login é real?”** Ainda não. A senha é validada localmente para demonstrar a interface, mas a versão acadêmica não usa autenticação de servidor.

**“Se outra pessoa se inscrever no celular, eu consigo ver?”** Ainda não. Isso depende de banco de dados e backend, que fazem parte de uma próxima evolução do produto.

**“O que foi corrigido?”** A quantidade de eventos e vagas cresceu, a inscrição passou a gerar comprovante e histórico visível, criamos um acesso demonstrativo único com três registros prontos e adicionamos a consulta de participantes, check-in e edição de vagas.

**“Onde entra DevOps?”** A proposta de trabalho segue branches `feature/* → develop → testes/revisão → main → deploy`, com código e documentação versionados. O site pode ser publicado estaticamente pela Netlify e depois evoluir com uma integração contínua.
