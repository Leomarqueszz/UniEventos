# UniEventos — Guia para quem vai implementar novas ideias

## Resumo do projeto

Este repositório contém o **UniEventos 3.0**, protótipo acadêmico de site para eventos universitários feito com HTML, CSS e JavaScript puro (sem frameworks, sem build, sem servidor).

**Funcionalidades atuais:** página inicial, catálogo de 14 eventos fictícios, busca e filtros, detalhes, inscrição demonstrativa com comprovante, área do aluno, conta de teste, painel do organizador, edição de vagas, criação local de eventos, lista de inscritos, presença e exportação CSV. Há animações e modo de apresentação guiada.

## Executar localmente

1. Clone o repositório: `git clone https://github.com/USUARIO/REPOSITORIO.git`.
2. Entre na pasta `cd REPOSITORIO`.
3. Execute `python -m http.server 5500` (ou use a extensão Live Server do VS Code).
4. Abra `http://localhost:5500` no navegador.

Não precisa instalar pacotes para rodar o site. Conexão à internet pode ser necessária para fontes externas, caso existam.

## Onde alterar cada coisa

| Objetivo | Arquivo(s) |
|---|---|
| Alterar HTML base, menu, metadados | `index.html` |
| Alterar catálogo inicial, eventos, ocupação fictícia, categorias | `data.js` |
| Alterar inscrição, login demonstrativo, perfil, gestão e persistência local | `app.js` |
| Mudar estilo básico | `styles.css` |
| Ajustar detalhes visuais | `enhancements.css` |
| Alterar animações visuais | `motion.css`, `motion.js` |
| Conferir DevOps | `docs/DEVOPS.md` |
| Executar testes | `tests/test_v3.py` |

Arquivos JS são carregados no `index.html` nesta ordem: `data.js` -> `app.js` -> `motion.js`. Preserve as dependências dessa ordem caso não migre para módulos.

## Conta de demonstração

- E-mail: `leonardo@unieventos.demo`
- Senha **fictícia**: `Campus2026!`

A senha fica propositalmente no JavaScript e **não oferece autenticação segura**. Não há backend, nem banco de dados, nem permissão real de organizador.

## Persistência e limitações importantes

Os registros ficam no `localStorage` do próprio navegador: duas pessoas em dispositivos diferentes **não enxergam as mesmas inscrições**, e um usuário pode modificar dados pelo console do navegador. Quantidade de inscritos de exemplo é simulada. Um deploy da Netlify **não** transforma isso em banco de dados compartilhado.

Se a nova ideia do colega exigir vários usuários reais, base compartilhada ou controle de acesso, será preciso planejar uma API/backend, banco centralizado, autenticação real e autorização de administrador. Não trate a lógica do frontend como segurança.

## Fluxo recomendado de colaboração

1. Não trabalhar diretamente em `main`.
2. Criar branch `feature/nome-da-ideia` a partir de `develop`.
3. Realizar alterações com commits descritivos: `feat: ...`, `fix: ...`, `docs: ...`, `test: ...`.
4. Testar a navegação, login demonstrativo, inscrições, gestor e mobile.
5. Abrir Pull Request para `develop`; após revisão, integrar `main` e publicar.

Consulte `docs/DEVOPS.md` para o fluxo da atividade acadêmica.

## Testes automatizados

O arquivo `tests/test_v3.py` usa Python + Playwright com Chromium instalado em `/usr/bin/chromium`. É um teste de regressão preparado para o ambiente onde foi desenvolvido; pode exigir ajustar a localização do Chromium em outros computadores.

```
pip install playwright
python -m playwright install chromium
python tests/test_v3.py
```

Se necessário, substitua o `executable_path='/usr/bin/chromium'` do teste pelo Chromium instalado localmente.
