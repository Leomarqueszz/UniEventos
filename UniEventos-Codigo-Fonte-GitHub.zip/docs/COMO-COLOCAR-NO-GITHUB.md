# Enviar o UniEventos para o GitHub

## Pela interface (sem precisar de Git no computador)

1. Entre em https://github.com/new com a conta GitHub do dono do projeto.
2. Crie um repositório com nome `UniEventos` (público para acesso via link, ou privado se só a equipe tiver acesso).
3. Não marque opções para gerar README, `.gitignore` ou licença: estes arquivos já existem, ou a licença precisa ser decidida pela equipe.
4. Abra o repositório vazio e escolha **uploading an existing file** / **Add file > Upload files**.
5. Extraia o ZIP **antes**. Arraste o conteúdo da pasta extraída, com `index.html`, `app.js`, `data.js`, os CSS e também pastas `docs` e `tests`, para a página do GitHub. Não envie somente o ZIP; a ideia é expor o código-fonte editável.
6. Confirme em **Commit changes**.
7. Copie o endereço do repositório para seu amigo.

Se a interface não aceitar pasta por arrastar, faça o upload via Git (abaixo) para preservar `docs/` e `tests/`.

## Pelo terminal (recomendado)

Crie um repositório vazio no GitHub e, dentro da pasta extraída:

```bash
git init -b main
git add .
git commit -m "feat: versão 3.0 do UniEventos"
git remote add origin https://github.com/SEU_USUARIO/UniEventos.git
git push -u origin main

git checkout -b develop
git push -u origin develop
```

Troque `SEU_USUARIO` pelo login do GitHub e configure sua identidade Git se for a primeira vez (`git config --global user.name` / `user.email`). O GitHub exige autenticação adequada para o push.

## Como seu amigo começa

```bash
git clone https://github.com/SEU_USUARIO/UniEventos.git
cd UniEventos
git switch develop
git switch -c feature/nome-da-ideia
```

Depois ele executa o site com Live Server ou `python -m http.server 5500` e abre um Pull Request.

## Nota sobre deploy

Para Netlify, publique os arquivos web da raiz (HTML/CSS/JS). O repositório completo contém documentação e testes, que não precisam ser servidos publicamente. No Netlify, a pasta de publicação é a raiz (`.`) e não é necessário comando de build.
