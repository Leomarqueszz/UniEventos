# UniEventos 3.0 — Eventos Universitários

**Atividade 04 — Introdução ao DevOps** · Site acadêmico HTML + CSS + JavaScript.

O UniEventos preserva a estrutura criada para a disciplina: **Início → Explorar eventos → Detalhes → Inscrição/Comprovante → Minhas inscrições → Organizador**. A atualização 3.0 foi feita para uma demonstração ao vivo, mantendo as correções solicitadas pela professora.

## Login único para apresentar

| Campo | Acesso demonstrativo |
|---|---|
| **E-mail** | `leonardo@unieventos.demo` |
| **Senha** | `Campus2026!` |
| **Nome exibido** | Leonardo Marques |

Clique em **Entrar** no cabeçalho e use essas credenciais. Se quiser evitar digitar durante a aula, clique em **✦ Preencher acesso de teste** e depois **Entrar na minha área**.

- Na **primeira entrada neste navegador**, são criadas **três inscrições fictícias** (Tecnologia, Carreiras e Python), com comprovantes consultáveis e status de confirmação.
- Após novo evento, o sistema gera um código de inscrição e o acrescenta ao histórico.
- O aluno pode sair e entrar de novo, desde que utilize **o mesmo navegador/site** e não apague os dados locais.
- Não é login real: a senha está publicamente no JavaScript, para demonstração. **Não reutilize essa senha em contas reais.**

## Como apresentar com segurança

O botão **✦ Apresentar** fica no cabeçalho. Ele abre um roteiro de **sete etapas**, com uma frase curta para você falar e um botão **Próximo** que já navega até a parte correspondente. O roteiro pode ser fechado a qualquer momento.

**Demonstração sugerida:** Início → filtros → detalhes do evento → Entrar → Minhas inscrições → Organizador → Lista de presença. Para gerar uma **nova inscrição ao vivo**, use um evento fora dos três já cadastrados, por exemplo **Hackathon: IA aplicada a desafios reais**.

Leia também `docs/ROTEIRO-APRESENTACAO.md` para um script rápido e direto.

## Melhorias da versão 3.0

1. **Login demonstrativo por e-mail e senha**, com validação de credenciais, alternância mostrar/ocultar senha, preenchimento rápido e mensagem em caso de erro.
2. **Conta única de apresentação**, com três inscrições fictícias iniciais e histórico persistido.
3. **Área do participante repaginada**: saudação, banner premium, contador de inscrições, trilha de acompanhamento, estatísticas e cartões de eventos.
4. **Roteiro de apresentação embutido**, sete etapas com navegação imediata, indicação do ponto a mostrar e falas de apoio.
5. **Animações discretas e contínuas**: hero com profundidade, formas flutuantes, tickets, badges e gradientes reativos ao movimento do mouse.
6. **Transições de página e de rolagem**, cartões e botões com microinterações, progressos animados e números com contagem progressiva.
7. **Feedback de sucesso** com check animado, ticket de confirmação, confete leve e toasts; respeita acessibilidade e preferência por movimento reduzido.
8. **Painel do organizador com atalhos claros** para criar eventos, verificar participantes e editar vagas.
9. **Preservadas as correções da versão 2.0:** 14 eventos, capacidades grandes, busca/filtros, controle de inscritos, edição de capacidade, check-in e exportação CSV.
10. **Verificações automatizadas em Chromium**: login correto/incorreto, roteiro, busca, inscrição, comprovante, persistência, lista de presença, criação, vagas e responsividade.

## Publicação na Netlify

Para publicar no endereço já existente:

1. Baixe `UniEventos-V3-Netlify.zip` (entregue separadamente).
2. Entre em https://app.netlify.com e abra o **site UniEventos já criado**.
3. Em **Deploys**, faça o upload dos arquivos extraídos do ZIP (a pasta que contém `index.html` na raiz). A opção de upload de ZIP depende da interface de deploy; extrair e enviar a pasta costuma funcionar.
4. Quando o deploy terminar, atualize a página com **Ctrl + Shift + R**.
5. Abra o link em uma aba privada e teste a conta. Os três eventos iniciais são preparados quando o usuário entra pela primeira vez nesse navegador.

É um site estático; **não precisa de instalação ou de build** para a demonstração. O ZIP completo contém documentação e testes para o repositório GitHub.

## Estrutura do projeto

| Arquivo | Finalidade |
|---|---|
| `index.html` | Estrutura HTML, navegação e containers |
| `styles.css` | Estilos originais |
| `enhancements.css` | Polimento visual da versão 2.0 |
| `motion.css` | Microinterações, animações, dashboard e modo apresentação |
| `data.js` | Eventos e lotações **fictícios** |
| `app.js` | Fluxos do aluno, organizador, inscrições, login de teste e localStorage |
| `motion.js` | Animações progressivas, tour, contadores e celebração |
| `favicon.svg` | Ícone do UniEventos |
| `docs/ROTEIRO-APRESENTACAO.md` | Guia do que clicar e falar |
| `docs/DEVOPS.md` | Fluxo de trabalho conforme a atividade |
| `CHANGELOG.md` | Mudanças por versão |
| `tests/test_v3.py` | Testes automatizados em Chromium + Playwright |

## Limites do protótipo

**Atenção:** a validação de senha é executada no navegador e a senha está exposta no código-fonte. Isto **não protege dados ou áreas administrativas**. A Netlify publica o site, mas não cria um servidor de autenticação ou banco de dados.

- Os registros estão em `localStorage` e **não são compartilhados entre outros visitantes, navegadores ou dispositivos**.
- Os valores de ocupação e os perfis fictícios usados para ilustrar a lista não correspondem a estudantes reais.
- Não há autorização de organizador, confirmação de e-mail, integrações de pagamento nem certificado com validade oficial.
- Não utilize dados pessoais reais ou senhas sensíveis nesta versão.
- Para produção: autenticação segura em servidor (por exemplo, Supabase Auth), banco de dados centralizado e permissões organizacionais verificadas no servidor.

## Git, branches e DevOps

Proposta conforme a documentação da disciplina: `main` (estável), `develop` (integração), `feature/*` (recursos) e `fix/*` (correções). Commits: `feat:`, `fix:`, `docs:`, `test:`, `refactor:` e `style:`. Fluxo: desenvolvimento → integração em `develop` → testes/revisão → `main` → deploy → acompanhamento.

## Equipe

- Pedro Almeida Bonilha — Product Owner
- Henryque Marques de Oliveira — Scrum Master
- Leonardo Marques Silva — Arquiteto de Software
- Samir Santos de Melo — Dev/DevOps
- Vinícius Borges — Security Officer
- Davi Oliveira — Analista de Qualidade e Sustentabilidade
- Cristiano — Analista de Negócios
