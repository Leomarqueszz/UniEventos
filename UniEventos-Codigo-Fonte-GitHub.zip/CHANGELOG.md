# Histórico de melhorias — UniEventos

## v3.0 — 06/11/2026 · Apresentação ao vivo

- Conta única **Leonardo Marques**, e-mail `leonardo@unieventos.demo`, senha `Campus2026!` (validação **somente local**, não é autenticação segura).
- Semente inicial de três inscrições fictícias no primeiro login, histórico persistido no mesmo navegador, login inválido tratado, botão preencher e mostrar/ocultar senha.
- Nova área do aluno, com banner de boas-vindas, contadores, trilha de passos, status e comprovantes.
- Novo guia integrado para demonstração com 7 etapas navegáveis e falas curtas.
- Novos efeitos de movimento (hero, orbes, cards, abas, botões, barra de progresso, contagens, revelação no scroll, feedback e confete), com `prefers-reduced-motion`.
- Atalhos visuais no organizador para publicar eventos, consultar participantes e editar vagas.
- Testes em Chromium para credenciais, persistência, inscrição/comprovante, busca, check-in, vagas, criação, apresentação e larguras de 320–1920px.
- Mantidas as 14 atividades do catálogo, rotas e fluxos principais da versão anterior.
- Limitação reconhecida: sem backend, credenciais reais, compartilhamento de inscrições ou permissão de organizador.

## v2.0 — 06/11/2026

### Feedback da professora

- Aumento de 6 para 14 eventos fictícios e expansão das capacidades para centenas/milhares de vagas.
- Criação de uma confirmação completa de inscrição, com nome, evento, código, status, impressão e acesso pelo histórico.
- Identificação demonstrativa persistente; inscrições recuperáveis ao acessar o mesmo navegador com o mesmo e-mail.
- Painel de participantes ampliado, com distinção explícita entre perfis fictícios e inscrições locais.

### Experiência do aluno

- Novo perfil, métricas de inscrições, eventos futuros e presenças.
- Estado de **Inscrito** nos cartões de evento e detalhes, prevenindo inscrições duplicadas no mesmo navegador.
- Cancelamento de inscrição com atualização da ocupação local.
- Mais filtros (inclui período) e pesquisa por nome, tema, descrição e local.

### Organização dos eventos

- Ajuste de capacidade de vagas com validação para não reduzir abaixo da ocupação local + fictícia.
- Cadastro de novos eventos com limite demonstrativo de 100.000 vagas.
- Lista de participantes com busca, filtro de presença, check-in manual, exportação CSV e dados ilustrativos identificados.
- Contadores separados para ocupação ilustrativa, inscrições locais e presenças locais.

### Visual, acessibilidade e qualidade

- Layout preservado e aprimorado: hero, cartões, categorias, barra de filtros, detalhes, comprovantes e painel.
- Responsividade validada em resoluções de 320 a 1920 pixels, sem rolagem horizontal no corpo.
- Melhor contraste, foco por teclado, menu mobile e respeito a movimento reduzido.
- Fluxos testados: navegação, busca, filtros, inscrição, confirmação, persistência, logout/reentrada, duplicidade, edição de vagas, check-in, criação e cancelamento.
- Correção de datas do catálogo (evento inicialmente vencido estava datado de 05/11/2026).
- Código separado em `data.js`, `app.js`, `styles.css` e `enhancements.css` para facilitar manutenção.

### Limites assumidos

- Não há banco de dados, autenticação real, API, compartilhamento entre dispositivos ou e-mail. A demonstração **não se apresenta como aplicação produtiva**.
