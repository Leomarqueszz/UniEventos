"""UniEventos 3.0 — testes reais com Chromium, servidor HTTP local e localStorage."""
from playwright.sync_api import sync_playwright
from pathlib import Path
import re, json
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'tests'/'output'
OUT.mkdir(exist_ok=True)
def markup(data=None):
    html=(ROOT/'index.html').read_text()
    for f in ('styles.css','enhancements.css','motion.css'):
        html=html.replace(f'<link rel="stylesheet" href="{f}" />','')
    for f in ('data.js','app.js','motion.js'):
        html=html.replace(f'<script src="{f}" defer></script>','')
    css='\n'.join(re.sub(r'@import[^;]*;','',(ROOT/f).read_text()) for f in ('styles.css','enhancements.css','motion.css'))
    local='const localStorage = { _data: '+json.dumps(data or {},ensure_ascii=False)+', getItem(k) {return this._data[k]??null},setItem(k,v){this._data[k]=String(v)},removeItem(k){delete this._data[k]} };\n'
    js=local+'\n'.join((ROOT/f).read_text() for f in ('data.js','app.js','motion.js'))
    return html.replace('</head>','<style>'+css+'</style></head>').replace('</body>','<script>'+js+'</script></body>')
checks=[]
errors=[]
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 context=b.new_context(viewport={'width':1440,'height':920},device_scale_factor=1)
 page=context.new_page()
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content(markup(),wait_until='domcontentloaded')
 assert page.get_by_role('heading',name='As melhores experiências do campus estão aqui.').count()==1
 assert page.locator('.event-card').count()==6
 assert page.get_by_role('button',name='Abrir roteiro de apresentação').count()==1
 checks.append('Início e catálogo com animações carregados')
 # Guided presentation
 page.get_by_role('button',name='Abrir roteiro de apresentação').click()
 assert page.locator('.tour-panel').is_visible()
 assert page.get_by_text('O que é o UniEventos?').count()==1
 page.locator('[data-tour="next"]').click()
 page.wait_for_timeout(130)
 assert page.locator('#searchEvents').count()==1
 assert page.get_by_text('Encontre seu evento').count()==1
 page.locator('[data-tour="next"]').click()
 page.wait_for_timeout(130)
 assert page.locator('.sticky-card').count()==1
 page.locator('[data-tour="close"]').click()
 checks.append('Roteiro de apresentação navegável e fechável')
 # Actual demo login
 page.locator('#accountButton').click()
 assert page.locator('#loginForm').count()==1
 assert page.locator('#demoPassword').get_attribute('type')=='password'
 page.screenshot(path=str(OUT/'UniEventos-V3-Login.png'),animations='disabled')
 page.locator('#demoEmail').fill('errado@teste.demo')
 page.locator('#demoPassword').fill('123')
 page.locator('#loginForm button[type=submit]').click()
 assert page.get_by_text('E-mail ou senha incorretos.').count()==1
 page.locator('[data-action="fill-demo"]').click()
 assert page.locator('#demoEmail').input_value()=='leonardo@unieventos.demo'
 assert page.locator('#demoPassword').input_value()=='Campus2026!'
 page.locator('[data-action="toggle-password"]').click()
 assert page.locator('#demoPassword').get_attribute('type')=='text'
 page.locator('#loginForm button[type=submit]').click()
 page.wait_for_timeout(250)
 assert page.locator('.member-dashboard').count()==1
 assert page.locator('.registration').count()==3
 assert page.locator('.member-dashboard-card strong').inner_text()=='03'
 checks.append('Login com senha validada, botão preencher e 3 inscrições de exemplo')
 data=page.evaluate('localStorage._data')
 page.reload(wait_until='domcontentloaded')
 page.set_content(markup(data),wait_until='domcontentloaded')
 assert page.locator('.registration').count()==3
 checks.append('Inscrições preservadas ao atualizar página')
 # New actual enrollment
 page.locator('a[href="#eventos"]').first.click()
 page.wait_for_timeout(120)
 assert page.locator('.event-card').count()==14
 page.locator('#searchEvents').fill('Hackathon')
 assert page.locator('.event-card').count()==1
 page.locator('.event-card').get_by_role('link',name='Ver detalhes').click()
 page.wait_for_timeout(140)
 page.get_by_role('button',name='Garantir minha vaga').click()
 page.wait_for_timeout(250)
 assert '#confirmacao/' in page.url
 assert page.get_by_text('Seu lugar está garantido!').count()==1
 assert page.locator('.code-area strong').inner_text().startswith('UNI-')
 checks.append('Busca, detalhes, inscrição, confete e comprovante com código')
 # Organizer & dynamic enrollment
 page.locator('a[href="#organizador"]').first.click()
 page.wait_for_timeout(160)
 assert page.locator('.organizer-shortcuts button').count()==3
 assert page.locator('tbody tr').count()==14
 page.locator('button[data-action="organizer-attendees"][data-id="hackathon-ia"]').click()
 page.wait_for_timeout(150)
 page.locator('#attendeeSearch').fill('Leonardo')
 assert page.locator('.attendee-row').count()==1
 page.get_by_role('button',name='Confirmar presença').click()
 page.wait_for_timeout(150)
 assert 'Presente' in page.locator('.attendee-row .state-chip').inner_text()
 checks.append('Organizador exibe participante real, busca e confirma presença')
 page.locator('button[data-action="organizer-back"]').click()
 page.locator('button[data-action="edit-capacity"][data-id="hackathon-ia"]').click()
 page.locator('#newCapacity').fill('1800')
 page.locator('#capacityForm button[type="submit"]').click()
 page.wait_for_timeout(150)
 assert '1.800' in page.locator('tr').filter(has_text='Hackathon').inner_text()
 page.get_by_role('button',name='Criar evento',exact=True).click()
 page.locator('#eventTitle').fill('Mostra de Projetos de ADS')
 page.locator('#eventDate').fill('2027-01-23')
 page.locator('#eventTime').fill('14:30')
 page.locator('#eventPlace').fill('Auditório 5')
 page.locator('#eventSeats').fill('8500')
 page.locator('#eventHost').fill('Equipe ADS')
 page.locator('#eventSummary').fill('Uma mostra de projetos universitários.')
 page.locator('#eventDescription').fill('Mostra aberta de projetos de desenvolvimento de software, dados e inovação.')
 page.locator('#newEventForm button[type="submit"]').click()
 page.wait_for_timeout(150)
 assert page.locator('tbody tr').count()==15
 checks.append('Edição de capacidade, novo evento com 8.500 vagas')
 # One walkthrough to organizer attendance
 page.get_by_role('button',name='Abrir roteiro de apresentação').click()
 page.locator('[data-tour="step"][data-index="6"]').click()
 assert page.locator('.attendees-panel').count()==1
 page.locator('[data-tour="close"]').click()
 checks.append('Roteiro avança para lista de presença')
 # Back to dashboard
 page.locator('a[href="#inscricoes"]').first.click()
 page.wait_for_timeout(160)
 assert page.locator('.registration').count()==4
 assert page.get_by_role('button',name='Certificado').count()==1
 # Sign out and in
 page.locator('#accountButton').click()
 page.get_by_role('button',name='Sair',exact=True).click()
 page.wait_for_timeout(150)
 page.locator('a[href="#inscricoes"]').first.click()
 page.wait_for_timeout(150)
 assert page.locator('.empty-profile').count()==1
 page.locator('#accountButton').click()
 page.locator('[data-action="fill-demo"]').click()
 page.locator('#loginForm button[type=submit]').click()
 page.wait_for_timeout(160)
 assert page.locator('.registration').count()==4
 checks.append('Logout, login novamente e histórico preservado')
 # Desktop screenshots after revealing entire page
 page.evaluate("location.hash='#inicio'")
 page.wait_for_timeout(140)
 for y in range(0,3100,550):
  page.evaluate('(y)=>window.scrollTo(0,y)',y)
  page.wait_for_timeout(100)
 page.evaluate('window.scrollTo(0,0)')
 page.wait_for_timeout(650)
 page.evaluate("document.querySelectorAll('.reveal-ready').forEach(el=>el.classList.add('is-visible'));document.getElementById('toastRoot').replaceChildren()")
 page.screenshot(path=str(OUT/'UniEventos-V3-Desktop.png'),full_page=True,animations='disabled')
 page.evaluate("location.hash='#inscricoes'")
 page.wait_for_timeout(120)
 page.wait_for_timeout(800)
 page.evaluate("document.querySelectorAll('.reveal-ready').forEach(el=>el.classList.add('is-visible'));document.getElementById('toastRoot').replaceChildren()")
 page.screenshot(path=str(OUT/'UniEventos-V3-Painel-Aluno.png'),full_page=True,animations='disabled')
 page.evaluate("location.hash='#organizador'")
 page.wait_for_timeout(120)
 page.wait_for_timeout(700)
 page.evaluate("document.querySelectorAll('.reveal-ready').forEach(el=>el.classList.add('is-visible'));document.getElementById('toastRoot').replaceChildren()")
 page.screenshot(path=str(OUT/'UniEventos-V3-Organizador.png'),full_page=True,animations='disabled')
 # Mobile sizes
 for width in (320,375,390,768,1024,1440,1920):
  page.set_viewport_size({'width':width,'height':860})
  for route in ('#inicio','#eventos','#inscricoes','#organizador'):
   page.evaluate('(hash)=>location.hash=hash',route)
   page.wait_for_timeout(75)
   dimensions=page.evaluate('({scrollWidth:document.documentElement.scrollWidth,innerWidth:window.innerWidth})')
   assert dimensions['scrollWidth']<=dimensions['innerWidth']+1, (width,route,dimensions)
  if width==390:
   page.evaluate("location.hash='#inicio'")
   page.wait_for_timeout(250)
   page.locator('#menuButton').click()
   assert page.locator('#mobileNav').is_visible()
   page.locator('#mobileNav a[href="#eventos"]').click()
   page.wait_for_timeout(180)
   page.evaluate("state.search='';state.category='Todos';state.format='Todos';state.period='Todos';render(false)")
   assert page.locator('.event-card').count()==15
   page.evaluate("location.hash='#inicio'")
   page.wait_for_timeout(140)
   for y in range(0,5800,500):
    page.evaluate('(y)=>window.scrollTo(0,y)',y)
    page.wait_for_timeout(50)
   page.evaluate('window.scrollTo(0,0)')
   page.wait_for_timeout(750)
   page.evaluate("document.querySelectorAll('.reveal-ready').forEach(el=>el.classList.add('is-visible'));document.getElementById('toastRoot').replaceChildren()")
   page.screenshot(path=str(OUT/'UniEventos-V3-Mobile.png'),full_page=True,animations='disabled')
 checks.append('Sem rolagem lateral: 320, 375, 390, 768, 1024, 1440 e 1920px × 4 páginas')
 assert not errors,errors
 checks.append('Sem exceções de JavaScript no navegador')
 print(json.dumps({'status':'PASSOU','checks':checks,'errors':errors,'screenshots':[str(x) for x in OUT.glob('UniEventos-V3-*.png')]},ensure_ascii=False,indent=2))
 context.close();b.close()

