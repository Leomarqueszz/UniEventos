/* UniEventos 3.0 — animação progressiva + roteiro de apresentação.
   Todos os efeitos respeitam prefers-reduced-motion e não bloqueiam a navegação. */
(() => {
  'use strict';
  const reduced = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
  let revealObserver, numberObserver, highlighted;
  const root = document.getElementById('presentationRoot');
  const steps = [
    { title:'O que é o UniEventos?', page:'#inicio', target:'.hero', cue:'Aqui está nossa plataforma: um lugar para encontrar, divulgar e participar dos eventos da universidade.' },
    { title:'Encontre seu evento', page:'#eventos', target:'.filter-bar', cue:'Agora é possível pesquisar, filtrar por categoria, formato e data. O catálogo já tem 14 eventos de exemplo.' },
    { title:'Detalhes e vagas', page:'#evento/semana-tecnologia', target:'.sticky-card', cue:'Cada evento tem descrição, data, local, capacidade e um botão para garantir a inscrição.' },
    { title:'Login com senha', page:'#inscricoes', target:'.empty-profile, .member-dashboard', cue:'Clique em Entrar, use o acesso de demonstração e veja a área do participante com três inscrições preparadas.' },
    { title:'Comprovantes e status', page:'#inscricoes', target:'.registration-list, .member-dashboard', cue:'As inscrições ficam organizadas aqui, com comprovantes, códigos de confirmação e acompanhamento da presença.' },
    { title:'Painel do organizador', page:'#organizador', target:'.organizer-shortcuts', cue:'O organizador pode publicar eventos, ajustar vagas e consultar as participações em um painel.' },
    { title:'Lista de presença', page:'#organizador', target:'.attendees-panel', organizerAttendees:true, cue:'Por fim, mostramos a lista de inscritos, busca por participante, presença e exportação de CSV.' }
  ];
  let tourOpen = false, tourStep = 0;
  const interpolate = (from, to, elapsed) => from + (to-from) * (1-Math.pow(1-elapsed,3));
  function animateNumber(el) {
    if(el.dataset.countAnimated || reduced) return;
    const raw=el.textContent.trim();
    const match=raw.match(/^(\d[\d.]*)(\+|%)?$/);if(!match)return;
    const value=Number(match[1].replace(/\./g,''));if(!Number.isFinite(value))return;
    const suffix=match[2]||'', padded=match[1].startsWith('0')&&match[1].length===2;
    el.dataset.countAnimated='1';
    const start=performance.now(),duration=950;
    function tick(now){
      const t=Math.min(1,(now-start)/duration),n=Math.round(interpolate(0,value,t));
      el.textContent=(padded?String(n).padStart(2,'0'):n.toLocaleString('pt-BR'))+suffix;
      if(t<1&&el.isConnected)requestAnimationFrame(tick);else el.textContent=raw;
    }
    requestAnimationFrame(tick);
  }
  function refresh() {
    if(revealObserver)revealObserver.disconnect();
    if(numberObserver)numberObserver.disconnect();
    const revealNodes=[...document.querySelectorAll('#app .section-top, #app .category-tile, #app .event-card, #app .step, #app .callout, #app .detail-panel, #app .sticky-card, #app .registration, #app .stat-card, #app .member-dashboard, #app .journey-track, #app .organizer-shortcuts, #app .panel, #app .confirmation-panel')];
    if (!reduced && 'IntersectionObserver' in window) {
      revealObserver=new IntersectionObserver(entries=>{
        entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('is-visible');revealObserver.unobserve(entry.target);}});
      },{rootMargin:'0px 0px 70px 0px',threshold:.035});
      revealNodes.forEach((node,i)=>{node.style.setProperty('--reveal-delay', `${(i%3)*75}ms`);node.classList.add('reveal-ready');revealObserver.observe(node)});
    }
    const nums=[...document.querySelectorAll('#app .hero-stats strong, #app .stats-grid .stat-card strong')];
    if(!reduced && 'IntersectionObserver' in window){
      numberObserver=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){animateNumber(e.target);numberObserver.unobserve(e.target)}}),{threshold:.6});
      nums.forEach(node=>numberObserver.observe(node));
    }
    window.requestAnimationFrame(updateTourHighlight);
  }
  function clearHighlight(){if(highlighted){highlighted.classList.remove('tour-highlight');highlighted=null;}}
  function updateTourHighlight(){
    clearHighlight();if(!tourOpen)return;
    const target=document.querySelector(steps[tourStep].target);
    if(target){highlighted=target;target.classList.add('tour-highlight');}
  }
  function drawTour(){
    if(!tourOpen){root.innerHTML='';clearHighlight();return;}
    const s=steps[tourStep];
    root.innerHTML=`<section class="tour-panel" aria-label="Roteiro de apresentação"><div class="tour-top"><span class="tour-tag"><span class="tour-live-dot"></span> GUIA DA APRESENTAÇÃO</span><button class="tour-close" type="button" data-tour="close" aria-label="Fechar guia">×</button></div><h3>${String(tourStep+1).padStart(2,'0')}. ${s.title}</h3><p>${s.cue}</p><div class="tour-dots" aria-label="Etapas">${steps.map((step,i)=>`<button type="button" data-tour="step" data-index="${i}" class="${i===tourStep?'active':''}" aria-label="Ir para etapa ${i+1}: ${step.title}" ${i===tourStep?'aria-current="step"':''}></button>`).join('')}</div><div class="tour-actions"><button class="tour-prev" type="button" data-tour="previous" ${tourStep===0?'disabled':''}>← Anterior</button><span class="tour-foot">${tourStep+1} de ${steps.length} etapas</span><button class="tour-next" type="button" data-tour="next">${tourStep===steps.length-1?'Finalizar ✓':'Próximo →'}</button></div></section>`;
    updateTourHighlight();
  }
  function showStep(i){
    if(i<0||i>=steps.length){tourOpen=false;drawTour();return;}
    tourStep=i;
    const s=steps[i];
    if(s.organizerAttendees){
      state.organizerTab='presencas';state.selectedOrganizerEvent='semana-tecnologia';state.attendeeSearch='';state.attendeeFilter='Todos';
    }else if(s.page==='#organizador' && state.organizerTab==='presencas') state.organizerTab='resumo';
    if(location.hash!==s.page) location.hash=s.page;else render(true);
    drawTour();
  }
  function celebrate() {
    if(reduced) return;
    const layer=document.getElementById('celebrationRoot');if(!layer)return;
    layer.replaceChildren();
    const colors=['#685cf0','#9a86ff','#ffbd6d','#3ac69f','#f57d9b'];
    for(let i=0;i<44;i++){
      const piece=document.createElement('i');piece.className='confetti-piece';
      piece.style.setProperty('--x',`${(i*37.9)%100}%`);
      piece.style.setProperty('--w',`${5+i%6}px`);piece.style.setProperty('--h',`${8+i%11}px`);
      piece.style.setProperty('--color',colors[i%colors.length]);piece.style.setProperty('--rotate',`${i*19}deg`);
      piece.style.setProperty('--drift',`${(i%2?1:-1)*(25+(i*13)%110)}px`);
      piece.style.setProperty('--duration',`${2+(i%10)*.14}s`);piece.style.setProperty('--delay',`${(i%8)*.05}s`);
      layer.appendChild(piece);
    }
    setTimeout(()=>layer.replaceChildren(),3800);
  }
  document.getElementById('presentationButton')?.addEventListener('click',()=>{if(tourOpen){tourOpen=false;drawTour();}else{tourOpen=true;showStep(0)}});
  document.addEventListener('click',event=>{
    const control=event.target.closest('[data-tour]');if(!control)return;
    const action=control.dataset.tour;
    if(action==='close'){tourOpen=false;drawTour();}
    if(action==='next')showStep(tourStep+1);
    if(action==='previous')showStep(tourStep-1);
    if(action==='step')showStep(Number(control.dataset.index));
  });
  document.addEventListener('keydown',event=>{if(event.key==='Escape'&&tourOpen&&!document.getElementById('modalBackdrop')){tourOpen=false;drawTour()}});
  document.addEventListener('pointermove',event=>{
    if(reduced)return;
    const hero=event.target.closest?.('.hero');if(!hero)return;
    const rect=hero.getBoundingClientRect();
    hero.style.setProperty('--hero-x',`${event.clientX-rect.left}px`);
    hero.style.setProperty('--hero-y',`${event.clientY-rect.top}px`);
  },{passive:true});
  window.unieventsMotion={refresh,celebrate};
  refresh();
})();
