# Como contribuir com o UniEventos

Leia `docs/GUIA-PARA-DESENVOLVEDOR.md` e `docs/DEVOPS.md` antes de começar.

- Branch principal: `main` (versão estável).
- Branch de integração: `develop`.
- Funcionalidade nova: `feature/nome`.
- Correção: `fix/nome`.
- PR para `develop`, com o que mudou, prints da interface, impacto em login e inscrições, passos para testar e possíveis limitações.

**Importante:** este repositório é um protótipo acadêmico sem backend. Nunca use informações pessoais reais ou senhas verdadeiras como dados de teste.
