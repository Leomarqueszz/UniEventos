/*
 * UniEventos 2.0 — Protótipo acadêmico responsivo.
 * Acesso, inscrições e listas são demonstrações locais, NÃO autenticação real.
 * Sem backend, múltiplos dispositivos NÃO compartilham inscritos/vagas.
 */
'use strict';

const STORAGE = {
  user: 'unieventos.user.v1',
  events: 'unieventos.custom.v1',
  registrations: 'unieventos.registrations.v1',
  overrides: 'unieventos.capacity.v2',
  attendance: 'unieventos.sample.attendance.v2',
  demoSeed: 'unieventos.demo.seeded.v3'
};
const app = document.getElementById('app');
const modalRoot = document.getElementById('modalRoot');
const toastRoot = document.getElementById('toastRoot');
const DEMO_ACCOUNT = Object.freeze({ name: 'Leonardo Marques', email: 'leonardo@unieventos.demo', password: 'Campus2026!' });
const DEMO_STARTER_EVENTS = ['semana-tecnologia', 'feira-carreiras', 'workshop-python'];
const state = { search: '', category: 'Todos', format: 'Todos', period: 'Todos', organizerTab: 'resumo', selectedOrganizerEvent: null, attendeeSearch: '', attendeeFilter: 'Todos', pendingSignup: null, showPassword: false };

const read = (key, fallback) => { try { const item = localStorage.getItem(key); return item === null ? fallback : JSON.parse(item); } catch { return fallback; } };
function save(key, value) { try { localStorage.setItem(key, JSON.stringify(value)); return true; } catch { toast('Armazenamento local indisponível. Tente liberar espaço no navegador.', true); return false; } }
let currentUser = read(STORAGE.user, null);
let customEvents = read(STORAGE.events, []);
let registrations = read(STORAGE.registrations, []);
let capacityOverrides = read(STORAGE.overrides, {});
let sampleAttendance = read(STORAGE.attendance, {});
if (!Array.isArray(customEvents)) customEvents = [];
if (!Array.isArray(registrations)) registrations = [];
if (!capacityOverrides || typeof capacityOverrides !== 'object' || Array.isArray(capacityOverrides)) capacityOverrides = {};
if (!sampleAttendance || typeof sampleAttendance !== 'object' || Array.isArray(sampleAttendance)) sampleAttendance = {};
if (!currentUser || typeof currentUser !== 'object' || !currentUser.email || !currentUser.name || String(currentUser.email).toLowerCase() !== DEMO_ACCOUNT.email) currentUser = null;

const clean = (str, max = 400) => String(str ?? '').trim().slice(0, max);
const escapeHtml = (str) => String(str ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const escapeAttr = escapeHtml;
const prettyNumber = (num) => Number(num).toLocaleString('pt-BR');
const today = () => { const d = new Date(); return [d.getFullYear(), String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-'); };
const localDate = (iso) => new Date(`${iso}T12:00:00`);
const prettyDate = (iso, opts = {day:'2-digit', month:'long', year:'numeric'}) => localDate(iso).toLocaleDateString('pt-BR', opts);
const shortDate = (iso) => prettyDate(iso, {day:'2-digit',month:'short'}).replace('.','');
const day = (iso) => localDate(iso).getDate().toString().padStart(2,'0');
const month = (iso) => prettyDate(iso,{month:'short'}).replace('.','');
const isPast = (event) => event.date < today();
const normalizeEmail = (email) => clean(email, 150).toLowerCase();
const route = () => { try { return decodeURIComponent((location.hash || '#inicio').slice(1)).split('/'); } catch { return ['inicio']; } };
const allEvents = () => [...SEED_EVENTS, ...customEvents].map(e => ({...e,seats: Number(capacityOverrides[e.id]) || Number(e.seats) || 1}));
const getEvent = (id) => allEvents().find(e => e.id === id);
const demoCount = (event) => Number(DEMO_OCCUPANCY[event.id]) || 0;
const realRegistrations = (id) => registrations.filter(r => r.eventId === id);
const localCount = (event) => realRegistrations(event.id).length;
const occupied = (event) => demoCount(event) + localCount(event);
const available = (event) => Math.max(0, event.seats - occupied(event));
const percent = (event) => Math.min(100, Math.round(occupied(event) / event.seats * 100));
const myRegistration = (id) => currentUser ? registrations.find(r => r.eventId === id && normalizeEmail(r.email) === normalizeEmail(currentUser.email)) : null;
const myRegistrations = () => currentUser ? registrations.filter(r => normalizeEmail(r.email) === normalizeEmail(currentUser.email)) : [];
const slugify = (val) => val.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,'-').replace(/(^-|-$)/g,'');
const confirmationCode = (r) => `UNI-${String(r.id).replace(/[^a-z0-9]/gi,'').slice(-9).toUpperCase()}`;

function toast(message, error = false) {
  const node = document.createElement('div');
  node.className = `toast${error ? ' error' : ''}`;
  node.setAttribute('role', error ? 'alert' : 'status');
  node.textContent = message;
  toastRoot.appendChild(node);
  setTimeout(() => node.remove(), 4500);
}
function navigate(hash) { if (location.hash === hash) render(); else location.hash = hash; }
function seedDemoDashboard() {
  if (read(STORAGE.demoSeed, false)) return;
  const existing = new Set(registrations.filter(r=>r.email===DEMO_ACCOUNT.email).map(r=>r.eventId));
  const starter = DEMO_STARTER_EVENTS.filter(eventId=>!existing.has(eventId)).map((eventId,i)=>({
    id: `demonstra-2026-${eventId}`,eventId,name:DEMO_ACCOUNT.name,email:DEMO_ACCOUNT.email,
    checkedIn: false,createdAt:new Date(2026,10,6,12-i,20).toISOString(),demoStarter:true
  }));
  const next=[...registrations,...starter];
  if (!save(STORAGE.registrations,next)) return;
  registrations=next;
  save(STORAGE.demoSeed,true);
}
function updateAccount() {
  document.getElementById('avatarInitial').textContent = currentUser ? currentUser.name.slice(0,1).toUpperCase() : '?';
  document.getElementById('accountLabel').textContent = currentUser ? currentUser.name.split(' ')[0] : 'Entrar';
  document.getElementById('accountButton').setAttribute('aria-label', currentUser ? `Meu perfil: ${currentUser.name}` : 'Entrar na demonstração');
}
function updateNav() {
  const selected = route()[0] === 'evento' ? 'eventos' : route()[0] === 'confirmacao' ? 'inscricoes' : route()[0];
  document.querySelectorAll('[data-nav]').forEach(link => {
    const active = link.dataset.nav === selected;
    link.classList.toggle('active', active);
    if (active) link.setAttribute('aria-current','page'); else link.removeAttribute('aria-current');
  });
  closeMobileMenu();
}
function closeMobileMenu() { const menu=document.getElementById('mobileNav');menu.hidden=true;document.getElementById('menuButton').setAttribute('aria-expanded','false'); }
function cover(event, detail=false) {
  const colors=Array.isArray(event.colors) && event.colors.length === 2 ? event.colors : ['#33379c','#8c75fa'];
  const emoji=escapeHtml(event.emoji || '📅');
  return `<div class="event-cover ${detail ? 'detail-cover' : ''}" style="background:linear-gradient(125deg,${colors[0]},${colors[1]})">
  <div class="cover-circles"></div><span class="cover-graphic" aria-hidden="true">${emoji}</span>
  <span class="cover-stamp">${escapeHtml(event.coverLabel || 'UNIEVENTOS')}</span>
  ${detail?'':`<div class="event-date"><strong>${day(event.date)}</strong><span>${month(event.date)}</span></div>`}</div>`;
}
function capacityLine(event, label=true) {
  return `<div class="capacity-line"><div class="capacity-copy"><span>${label ? 'Participações ilustrativas + locais' : 'Ocupação demonstrativa'}</span><strong>${prettyNumber(occupied(event))} / ${prettyNumber(event.seats)}</strong></div>
  <div class="capacity-track" role="progressbar" aria-label="Ocupação demonstrativa" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${percent(event)}"><span style="width:${percent(event)}%"></span></div></div>`;
}
function card(event) {
  const seats=available(event),already=myRegistration(event.id),past=isPast(event);
  return `<article class="event-card">${cover(event)}<div class="event-card-body"><div class="card-flags"><span class="pill">${escapeHtml(event.category)}</span>${already?'<span class="status-mini">✓ Inscrito</span>':past?'<span class="status-mini archived">Encerrado</span>':''}</div>
  <h3>${escapeHtml(event.title)}</h3><div class="event-meta"><span class="meta-icon">◷</span> ${prettyDate(event.date)} · ${escapeHtml(event.time)}</div>
  <div class="event-meta"><span class="meta-icon">⌖</span> ${escapeHtml(event.place)}</div>
  ${capacityLine(event, false)}<div class="event-card-footer"><span class="price ${!seats||past?'soldout':''}">${already?'✓ Inscrito':past?'Encerrado':seats?'Gratuito':'Esgotado'}</span>
  <a href="#evento/${encodeURIComponent(event.id)}" aria-label="Ver detalhes de ${escapeAttr(event.title)}">Ver detalhes <span aria-hidden="true">↗</span></a></div></div></article>`;
}
function categoryTiles() {
  return Object.entries(CATEGORY_INFO).map(([category,info])=>`<button type="button" class="category-tile" data-action="category" data-category="${escapeAttr(category)}"><span class="cat-icon" style="background:${info.bg}">${info.emoji}</span><span><strong>${escapeHtml(category)}</strong><small>${allEvents().filter(e=>e.category===category).length} eventos</small></span><span class="cat-arrow" aria-hidden="true">↗</span></button>`).join('');
}
function home() {
  const es=allEvents().sort((a,b)=>a.date.localeCompare(b.date));
  const upcoming=es.filter(e=>!isPast(e));
  return `<section class="hero"><div class="container hero-inner"><div class="hero-copy"><span class="eyebrow"><span class="eyebrow-dot"></span> A SUA UNIVERSIDADE EM MOVIMENTO</span>
  <h1>As melhores experiências do <em>campus</em> estão aqui<span class="hero-period">.</span></h1>
  <p>Palestras, workshops, carreiras, cultura e conexões que transformam a vida universitária. O próximo grande momento começa aqui.</p>
  <div class="hero-actions"><a class="btn btn-primary" href="#eventos">Explorar eventos <span aria-hidden="true">↗</span></a><a class="btn btn-outline-light" href="#organizador">Publicar um evento →</a></div>
  ${currentUser?`<div class="member-hero-chip"><span class="member-online-dot"></span><div><strong>Bem-vindo de volta, ${escapeHtml(currentUser.name.split(' ')[0])}!</strong><small>${myRegistrations().length} inscrições no seu painel</small></div><a href="#inscricoes">Abrir minha área ↗</a></div>`:''}
  <div class="hero-stats"><div><strong>${prettyNumber(es.length)}+</strong><span>Eventos no catálogo</span></div><div><strong>${Object.keys(CATEGORY_INFO).length.toString().padStart(2,'0')}</strong><span>Categorias</span></div><div><strong>100%</strong><span>Participação gratuita</span></div></div></div>
  <div class="hero-visual" aria-hidden="true"><div class="orb one"></div><div class="orb two"></div><div class="orb three"></div><div class="ticket"><span class="ticket-label">SEU PRÓXIMO EVENTO</span><h3>IDEIAS QUE CONECTAM.</h3><div class="ticket-bottom"><span>UniEventos • 2026</span><div class="ticket-code">${'<i></i>'.repeat(14)}</div></div></div><div class="floating-badge float-one"><span class="float-icon">🎟️</span><span>Inscrição confirmada<small>Com comprovante</small></span></div><div class="floating-badge float-two"><span class="float-icon">✨</span><span>Novas conexões<small>Novas oportunidades</small></span></div></div></div></section>
  <div class="trust-strip"><div class="container trust-inner"><span>✧ CONEXÃO UNIVERSITÁRIA</span><span>✦ EXPERIÊNCIAS QUE TRANSFORMAM</span><span>✧ SUA JORNADA, SEU CAMPUS</span></div></div>
  <section class="content-section container"><div class="section-top"><div><span class="eyebrow"><span class="eyebrow-dot"></span> ESCOLHA SUA EXPERIÊNCIA</span><h2>Explore por categoria</h2><p>Descubra assuntos, pessoas e oportunidades que fazem sentido para você.</p></div></div><div class="category-strip">${categoryTiles()}</div>
  <div class="section-top"><div><span class="eyebrow"><span class="eyebrow-dot"></span> ACONTECENDO EM BREVE</span><h2>Próximos eventos</h2><p>Uma seleção de experiências para viver além da sala de aula.</p></div><a class="link-action" href="#eventos">Ver todos os eventos →</a></div>
  <div class="event-grid">${(upcoming.length?upcoming:es).slice(0,6).map(card).join('')}</div><p class="demo-disclaimer">* Eventos, datas e números de participantes são ilustrativos; as inscrições feitas por você são salvas neste navegador.</p></section>
  <section class="how-section"><div class="container"><div class="section-top"><div><span class="eyebrow"><span class="eyebrow-dot"></span> SIMPLES DO COMEÇO AO FIM</span><h2>Sua próxima experiência em 3 passos</h2><p>Do primeiro clique até o comprovante da inscrição.</p></div></div>
  <div class="steps"><article class="step"><div class="step-number">01</div><h3>Descubra</h3><p>Explore os eventos e use os filtros para encontrar o que mais combina com você.</p></article><article class="step"><div class="step-number">02</div><h3>Inscreva-se</h3><p>Identifique-se, confirme a participação e receba um código de inscrição.</p></article><article class="step"><div class="step-number">03</div><h3>Acompanhe</h3><p>Veja o status em Minhas inscrições e consulte seu comprovante quando quiser.</p></article></div>
  <div class="callout"><div><span class="callout-kicker">VOCÊ TAMBÉM PODE ORGANIZAR</span><h2>Tem uma ideia de evento?</h2><p>Crie experiências, acompanhe participantes e gerencie presenças no painel.</p></div><a href="#organizador" class="btn btn-white">Criar meu evento →</a></div></div></section>`;
}
function filters() {
  return `<div class="filter-bar"><label class="search-wrap"><span class="invisible">Pesquisar eventos</span><input id="searchEvents" class="search-input" type="search" maxlength="100" placeholder="Busque por nome, tema ou local..." value="${escapeAttr(state.search)}" autocomplete="off"></label>
  <label><span class="invisible">Categoria</span><select id="filterCategory" class="filter-select"><option value="Todos">Todas as categorias</option>${Object.keys(CATEGORY_INFO).map(cat=>`<option value="${cat}" ${state.category===cat?'selected':''}>${cat}</option>`).join('')}</select></label>
  <label><span class="invisible">Formato</span><select id="filterFormat" class="filter-select">${['Todos','Presencial','Online','Híbrido'].map(x=>`<option value="${x}" ${state.format===x?'selected':''}>${x==='Todos'?'Todos os formatos':x}</option>`).join('')}</select></label>
  <label><span class="invisible">Período</span><select id="filterPeriod" class="filter-select">${[['Todos','Todas as datas'],['Futuros','Próximos eventos'],['Mes','Este mês']].map(([val,label])=>`<option value="${val}" ${state.period===val?'selected':''}>${label}</option>`).join('')}</select></label></div>`;
}
function filteredEvents() {
  const q=state.search.toLocaleLowerCase('pt-BR');
  const currentMonth=today().slice(0,7);
  return allEvents().filter(e => (state.category==='Todos'||e.category===state.category)
    &&(state.format==='Todos'||e.format===state.format)
    &&(state.period==='Todos'||(state.period==='Futuros'&&!isPast(e))||(state.period==='Mes'&&e.date.slice(0,7)===currentMonth))
    &&`${e.title} ${e.summary} ${e.description} ${e.place} ${e.host}`.toLocaleLowerCase('pt-BR').includes(q))
    .sort((a,b)=>a.date.localeCompare(b.date));
}
function fillEventList() {
  const target=document.getElementById('eventResults'); if(!target)return;
  const es=filteredEvents();
  document.getElementById('resultsCount').textContent=`${es.length} evento${es.length===1?' encontrado':'s encontrados'}`;
  target.innerHTML=es.length ? es.map(card).join('') : `<div class="empty" style="grid-column:1/-1"><div class="empty-symbol">🔎</div><h3>Nenhum evento encontrado</h3><p>Experimente outra pesquisa ou altere os filtros.</p><button type="button" class="btn btn-ghost" data-action="clear-filters">Limpar filtros</button></div>`;
}
function eventsPage() { return `<section class="page-wrap container"><div class="breadcrumb"><a href="#inicio">Início</a> / Explorar eventos</div><div class="page-heading"><span class="eyebrow"><span class="eyebrow-dot"></span> EXPLORE O CAMPUS</span><h1>Todos os eventos<span class="heading-dot">.</span></h1><p>Encontre atividades que combinam com seu momento universitário.</p></div>${filters()}<div class="results-toolbar"><span class="result-count" id="resultsCount"></span><span class="muted small">Catálogo com dados fictícios para apresentação.</span></div><div id="eventResults" class="event-grid"></div></section>`; }
function eventDetail(event) {
  const seats=available(event),already=myRegistration(event.id),past=isPast(event);
  return `<section class="page-wrap container"><div class="breadcrumb"><a href="#inicio">Início</a> / <a href="#eventos">Eventos</a> / ${escapeHtml(event.title)}</div><div class="detail-layout"><div class="detail-main">${cover(event,true)}
  <div class="detail-category"><span class="pill">${escapeHtml(event.category)}</span><span class="detail-format">${escapeHtml(event.format)}</span></div><h1>${escapeHtml(event.title)}</h1><p class="detail-lead">${escapeHtml(event.summary)}</p>
  <section class="detail-panel"><h2>Sobre este evento</h2><p>${escapeHtml(event.description)}</p></section><section class="detail-panel"><h2>O que você vai encontrar</h2><ul>${(event.topics||[]).map(topic=>`<li>${escapeHtml(topic)}</li>`).join('')}</ul></section><section class="detail-panel"><h2>Organização</h2><p>${escapeHtml(event.host)}</p></section></div>
  <aside class="sticky-card"><span class="side-title">SUA EXPERIÊNCIA</span><div class="side-price">Gratuito <span class="free-label">entrada livre</span></div>
  <div class="side-detail"><span class="detail-emoji">📅</span><div><strong>Data e horário</strong><span>${prettyDate(event.date)} · ${escapeHtml(event.time)}</span></div></div>
  <div class="side-detail"><span class="detail-emoji">📍</span><div><strong>Local</strong><span>${escapeHtml(event.place)}</span></div></div>
  <div class="side-detail"><span class="detail-emoji">🏫</span><div><strong>Formato</strong><span>${escapeHtml(event.format)}</span></div></div>
  <div class="side-detail"><span class="detail-emoji">🎟️</span><div><strong>Vagas disponíveis</strong><span>${prettyNumber(seats)} de ${prettyNumber(event.seats)}</span></div></div>
  ${capacityLine(event,false)}
  ${already?`<div class="signed-up-box"><span>✓</span><div><strong>Inscrição confirmada!</strong><small>Seu lugar já está registrado.</small></div></div><a class="btn btn-primary btn-full" href="#confirmacao/${encodeURIComponent(already.id)}">Ver meu comprovante →</a>`:
  `<button class="btn btn-primary btn-full" data-action="signup" data-id="${escapeAttr(event.id)}" ${seats<=0||past?'disabled':''}>${past?'Inscrições encerradas':seats>0?'Garantir minha vaga →':'Inscrições esgotadas'}</button>`}
  <p class="tiny-note">Ocupação ilustrativa + inscrições locais. Não há sincronização entre dispositivos.</p></aside></div></section>`;
}
function loggedOutPage() { return `<section class="page-wrap container"><div class="page-heading"><span class="eyebrow">SEU ESPAÇO</span><h1>Minhas inscrições<span class="heading-dot">.</span></h1><p>Seus eventos e comprovantes, todos no mesmo lugar.</p></div><div class="empty empty-profile"><div class="empty-symbol">🎟️</div><h3>Suas experiências começam aqui</h3><p>Entre com a conta de apresentação e veja três inscrições de exemplo, status e comprovantes.</p><button class="btn btn-primary" data-action="login">Entrar na minha área →</button></div></section>`; }
function statsSummary(items) {
  const confirmed=items.length,attended=items.filter(x=>x.checkedIn).length;
  const next=items.filter(x=>{const e=getEvent(x.eventId);return e&&!isPast(e);}).length;
  return `<div class="stats-grid metrics"><article class="stat-card"><div class="stat-icon">🎟️</div><strong>${confirmed}</strong><span>Inscrições confirmadas</span></article><article class="stat-card"><div class="stat-icon">📅</div><strong>${next}</strong><span>Eventos no calendário</span></article><article class="stat-card"><div class="stat-icon">✅</div><strong>${attended}</strong><span>Presenças registradas</span></article></div>`;
}
function registrationCard(r,e) {
  return `<article class="registration"><div class="registration-art" style="background:linear-gradient(135deg,${e.colors[0]},${e.colors[1]})">${escapeHtml(e.emoji)}</div><div class="registration-info"><span class="state-chip ${r.checkedIn?'':'wait'}">${r.checkedIn?'✓ Presença confirmada':'✓ Inscrição confirmada'}</span>
  <h3>${escapeHtml(e.title)}</h3><p>📅 ${prettyDate(e.date)} · ${escapeHtml(e.time)}</p><p>📍 ${escapeHtml(e.place)}</p><div class="registration-code">Código: <strong>${confirmationCode(r)}</strong></div></div><div class="registration-actions"><a href="#confirmacao/${encodeURIComponent(r.id)}" class="btn btn-primary btn-sm">Comprovante</a><a href="#evento/${encodeURIComponent(e.id)}" class="btn btn-outline btn-sm">Ver evento</a>${r.checkedIn?`<button data-action="certificate" data-id="${escapeAttr(r.id)}" class="btn btn-ghost btn-sm">Certificado</button>`:''}<button data-action="cancel" data-id="${escapeAttr(r.id)}" class="btn btn-danger btn-sm">Cancelar</button></div></article>`;
}
function registrationsPage() {
  if(!currentUser)return loggedOutPage();
  const mine=myRegistrations().map(r=>({r,e:getEvent(r.eventId)})).filter(x=>x.e).sort((a,b)=>(b.r.createdAt||'').localeCompare(a.r.createdAt||''));
  return `<section class="page-wrap container"><div class="breadcrumb"><a href="#inicio">Início</a> / Minhas inscrições</div><div class="page-heading"><span class="eyebrow"><span class="eyebrow-dot"></span> SEUS PRÓXIMOS PASSOS</span><h1>Minhas inscrições<span class="heading-dot">.</span></h1><p>Confirmações, eventos e comprovantes que você pode consultar quando quiser.</p></div><div class="member-dashboard"><div class="member-dashboard-copy"><span class="member-eyebrow"><i></i> ÁREA DO PARTICIPANTE</span><h2>Olá, ${escapeHtml(currentUser.name.split(' ')[0])}! <span aria-hidden="true">👋</span></h2><p>Sua jornada no campus, organizada em um único lugar. Aqui você acompanha os eventos e acessa os seus comprovantes.</p><div class="member-dashboard-actions"><a class="btn btn-white" href="#eventos">Encontrar novos eventos ↗</a><a class="btn btn-member-ghost" href="#perfil">Ver meu perfil →</a></div></div><div class="member-dashboard-card"><span>SEU PAINEL AGORA</span><strong>${String(mine.length).padStart(2,'0')}</strong><small>inscrições confirmadas</small><div class="mini-dash-line"><span style="width:${Math.min(100,mine.length*24+8)}%"></span></div><small>Registros demonstrativos deste navegador</small></div></div><div class="journey-track"><div><span class="journey-icon done">✓</span><span><strong>Perfil ativo</strong><small>Conta demonstrativa</small></span></div><span class="journey-connector"></span><div><span class="journey-icon done">✓</span><span><strong>Eventos escolhidos</strong><small>${mine.length} confirmações</small></span></div><span class="journey-connector"></span><div><span class="journey-icon">◎</span><span><strong>Próximo passo</strong><small>Participar e registrar presença</small></span></div></div>${statsSummary(mine.map(x=>x.r))}
  ${mine.length?`<div class="list-heading"><h2>Seus eventos <span>${mine.length}</span></h2><p>Inscrições salvas neste navegador.</p></div><div class="registration-list">${mine.map(({r,e})=>registrationCard(r,e)).join('')}</div>`:`<div class="empty"><div class="empty-symbol">📅</div><h3>Você ainda não se inscreveu</h3><p>Encontre seu próximo evento e garanta sua vaga em poucos cliques.</p><a class="btn btn-primary" href="#eventos">Explorar eventos →</a></div>`}</section>`;
}
function confirmationPage(id) {
  if (!currentUser) return loggedOutPage();
  const r=registrations.find(x=>x.id===id&&normalizeEmail(x.email)===normalizeEmail(currentUser.email));
  if (!r) return notFound();
  const e=getEvent(r.eventId);if(!e)return notFound();
  return `<section class="page-wrap container confirmation-container"><div class="breadcrumb"><a href="#inicio">Início</a> / <a href="#inscricoes">Minhas inscrições</a> / Comprovante</div><div class="confirmation-panel"><div class="confirmation-top"><div class="success-ring"><span>✓</span></div><span class="eyebrow"><span class="eyebrow-dot"></span> INSCRIÇÃO REALIZADA</span><h1>Seu lugar está garantido!</h1><p>Você se inscreveu com sucesso na demonstração do UniEventos. Confira o comprovante abaixo.</p></div><div class="confirmation-ticket"><div class="ticket-label-dark">COMPROVANTE DE INSCRIÇÃO <span>UNIEVENTOS</span></div><h2>${escapeHtml(e.title)}</h2><div class="ticket-details"><div><span>Participante</span><strong>${escapeHtml(r.name)}</strong></div><div><span>E-mail</span><strong>${escapeHtml(r.email)}</strong></div><div><span>Quando</span><strong>${prettyDate(e.date)} às ${escapeHtml(e.time)}</strong></div><div><span>Onde</span><strong>${escapeHtml(e.place)}</strong></div></div><div class="ticket-divider"><i></i><i></i></div><div class="code-area"><div><span>CÓDIGO DE CONFIRMAÇÃO</span><strong>${confirmationCode(r)}</strong></div><span class="confirmed-pill">✓ Confirmado</span></div><div class="barcode" aria-hidden="true">${'<i></i>'.repeat(34)}</div></div><div class="confirmation-actions"><a href="#inscricoes" class="btn btn-primary">Ver minhas inscrições →</a><button type="button" class="btn btn-outline" data-action="print-confirmation">Imprimir comprovante</button><button type="button" class="btn btn-ghost" data-action="copy-code" data-code="${confirmationCode(r)}">Copiar código</button></div><p class="tiny-note">Comprovante acadêmico fictício, sem validade oficial. O registro existe somente neste navegador.</p></div></section>`;
}
function profilePage() {
  if(!currentUser)return loggedOutPage();
  const mine=myRegistrations();
  return `<section class="page-wrap container profile-page"><div class="breadcrumb"><a href="#inicio">Início</a> / Meu perfil</div><div class="page-heading"><span class="eyebrow"><span class="eyebrow-dot"></span> SUA CONTA DEMONSTRATIVA</span><h1>Meu perfil<span class="heading-dot">.</span></h1><p>Gerencie sua identificação local e acompanhe suas experiências.</p></div><div class="profile-card"><div class="profile-avatar">${escapeHtml(currentUser.name[0].toUpperCase())}</div><div class="profile-details"><span>PARTICIPANTE</span><h2>${escapeHtml(currentUser.name)}</h2><p>${escapeHtml(currentUser.email)}</p><small>Armazenado somente neste navegador.</small></div><div class="profile-buttons"><button class="btn btn-outline" data-action="switch-profile">Entrar novamente</button><button class="btn btn-danger" data-action="logout">Sair</button></div></div>${statsSummary(mine)}<div class="panel profile-explainer"><h2>Como funciona este perfil?</h2><p>Este acesso é apenas um exemplo acadêmico. A senha de teste está no código-fonte; não se trata de autenticação segura. As inscrições ficam somente neste navegador e não são compartilhadas com outros dispositivos. Para produção, seria necessário um serviço de autenticação e banco de dados.</p><a href="#inscricoes" class="btn btn-primary">Minhas inscrições →</a></div></section>`;
}
function organizerHome() {
  const es=allEvents(); const demoTotal=es.reduce((sum,e)=>sum+demoCount(e),0);
  return `<div class="stats-grid"><article class="stat-card"><div class="stat-icon">📆</div><strong>${prettyNumber(es.length)}</strong><span>Eventos no catálogo</span></article><article class="stat-card"><div class="stat-icon">👥</div><strong>${prettyNumber(demoTotal)}</strong><span>Participações ilustrativas</span></article><article class="stat-card"><div class="stat-icon">🎟️</div><strong>${prettyNumber(registrations.length)}</strong><span>Inscrições locais registradas</span></article><article class="stat-card"><div class="stat-icon">✅</div><strong>${prettyNumber(registrations.filter(r=>r.checkedIn).length)}</strong><span>Presenças locais</span></article></div>
  <div class="organizer-shortcuts"><button type="button" data-action="organizer-new"><span class="shortcut-icon purple">✦</span><span><small>01 · ORGANIZE</small><strong>Publicar evento</strong><em>Formulário com vagas e detalhes</em></span><b>↗</b></button><button type="button" data-action="organizer-attendees" data-id="semana-tecnologia"><span class="shortcut-icon mint">♧</span><span><small>02 · PARTICIPANTES</small><strong>Lista de presença</strong><em>Busca e confirmação ao vivo</em></span><b>↗</b></button><button type="button" data-action="edit-capacity" data-id="feira-carreiras"><span class="shortcut-icon orange">◈</span><span><small>03 · CAPACIDADE</small><strong>Editar vagas</strong><em>Ajuste de lotação em poucos cliques</em></span><b>↗</b></button></div><div class="panel"><div class="panel-title"><div><h2>Gerenciar eventos</h2><p class="muted small">Controle de vagas, listas e inscrições de demonstração.</p></div><button class="btn btn-primary btn-sm" data-action="organizer-new">+ Novo evento</button></div>
  <div class="table-scroll"><table><thead><tr><th>Evento</th><th>Data</th><th>Ocupação demonstrativa</th><th>Vagas livres</th><th>Ações</th></tr></thead><tbody>${es.sort((a,b)=>a.date.localeCompare(b.date)).map(e=>`<tr><td><span class="table-event">${escapeHtml(e.title)}</span><small class="table-sub">${escapeHtml(e.category)}</small></td><td>${shortDate(e.date)}</td><td><strong>${prettyNumber(occupied(e))} / ${prettyNumber(e.seats)}</strong><div class="mini-track"><span style="width:${percent(e)}%"></span></div></td><td>${prettyNumber(available(e))}</td><td><div class="table-actions"><button class="btn btn-outline btn-sm" data-action="organizer-attendees" data-id="${escapeAttr(e.id)}">Participantes</button><button class="btn btn-ghost btn-sm" data-action="edit-capacity" data-id="${escapeAttr(e.id)}">Vagas</button>${e.custom?`<button class="btn btn-danger btn-sm" data-action="delete-event" data-id="${escapeAttr(e.id)}">Excluir</button>`:''}</div></td></tr>`).join('')}</tbody></table></div></div>`;
}
function newEventForm() {
  return `<div class="panel"><div class="panel-title"><h2>Publicar novo evento</h2><p class="muted small">Preencha os dados para simular a publicação de um evento.</p></div><form class="organizer-form" id="newEventForm"><div class="form-grid"><div class="form-row wide"><label for="eventTitle">Nome do evento *</label><input id="eventTitle" name="title" class="field" maxlength="100" minlength="5" required placeholder="Ex.: Palestra sobre inovação"></div>
  <div class="form-row"><label for="eventCategory">Categoria *</label><select id="eventCategory" name="category" class="field" required>${Object.keys(CATEGORY_INFO).map(c=>`<option>${c}</option>`).join('')}</select></div><div class="form-row"><label for="eventFormat">Formato *</label><select id="eventFormat" name="format" class="field" required><option>Presencial</option><option>Online</option><option>Híbrido</option></select></div>
  <div class="form-row"><label for="eventDate">Data *</label><input id="eventDate" name="date" type="date" class="field" min="${today()}" required></div><div class="form-row"><label for="eventTime">Horário *</label><input id="eventTime" name="time" type="time" class="field" required></div><div class="form-row"><label for="eventPlace">Local / Link *</label><input id="eventPlace" name="place" class="field" maxlength="90" required placeholder="Ex.: Auditório central"></div><div class="form-row"><label for="eventSeats">Quantidade de vagas *</label><input id="eventSeats" name="seats" type="number" min="1" max="100000" class="field" value="500" required><small class="field-note">Até 100.000 vagas nesta demonstração.</small></div>
  <div class="form-row wide"><label for="eventHost">Organizador *</label><input id="eventHost" name="host" class="field" maxlength="90" required placeholder="Ex.: Centro acadêmico"></div><div class="form-row wide"><label for="eventSummary">Descrição curta *</label><input id="eventSummary" name="summary" class="field" maxlength="180" required placeholder="Descreva o evento em uma frase"></div><div class="form-row wide"><label for="eventDescription">Descrição completa *</label><textarea id="eventDescription" name="description" class="field" rows="5" maxlength="1200" required placeholder="Conte o que vai acontecer no evento"></textarea></div></div><button type="submit" class="btn btn-primary">Publicar evento →</button></form></div>`;
}
const SAMPLE_NAMES=['Ana Beatriz','Carlos Eduardo','Maria Fernanda','João Pedro','Juliana Costa','Rafael Martins','Camila Oliveira','Lucas Ferreira','Beatriz Santos','Gabriel Almeida','Mariana Ribeiro','Pedro Henrique','Isabela Lima','Felipe Gomes','Larissa Rocha','Eduarda Nunes'];
function samplePeople(event) {
  if (!DEMO_OCCUPANCY[event.id]) return [];
  return SAMPLE_NAMES.map((name,i)=>({ id:`sample-${event.id}-${i}`,eventId:event.id,name,email:`exemplo${String(i+1).padStart(2,'0')}@example.invalid`,checkedIn:!!sampleAttendance[`sample-${event.id}-${i}`],demo:true }));
}
function attendeesPanel() {
  const e=getEvent(state.selectedOrganizerEvent);if(!e)return organizerHome();
  const actual=realRegistrations(e.id).map(x=>({...x,demo:false}));
  const examples=samplePeople(e);
  const all=[...actual,...examples];
  const q=state.attendeeSearch.toLowerCase();
  const people=all.filter(p => (state.attendeeFilter==='Todos'||(state.attendeeFilter==='Presentes'&&p.checkedIn)||(state.attendeeFilter==='Pendentes'&&!p.checkedIn)) && `${p.name} ${p.email}`.toLowerCase().includes(q));
  return `<div class="panel attendees-panel"><div class="panel-title"><div><h2>Participantes e presença</h2><p class="muted small">${escapeHtml(e.title)}</p></div><button class="btn btn-outline btn-sm" data-action="organizer-back">← Voltar</button></div>
  <div class="attendee-overview"><div><strong>${prettyNumber(occupied(e))}</strong><span>Ocupação demonstrativa</span></div><div><strong>${actual.length}</strong><span>Inscrições feitas aqui</span></div><div><strong>${examples.length}</strong><span>Perfis fictícios exibidos</span></div><div><strong>${prettyNumber(available(e))}</strong><span>Vagas livres</span></div></div>
  <div class="demo-alert"><strong>Lista ilustrativa:</strong> são mostrados até ${SAMPLE_NAMES.length} perfis fictícios como exemplo, além das inscrições feitas neste navegador. O total simulado é maior que a lista visível e não representa pessoas reais.</div>
  <div class="attendee-toolbar"><label><span class="invisible">Buscar pessoa</span><input class="field" id="attendeeSearch" placeholder="Buscar por nome ou e-mail" value="${escapeAttr(state.attendeeSearch)}"></label><label><span class="invisible">Filtrar presença</span><select id="attendeeFilter" class="field">${['Todos','Presentes','Pendentes'].map(x=>`<option ${state.attendeeFilter===x?'selected':''}>${x}</option>`).join('')}</select></label><button class="btn btn-ghost btn-sm" data-action="export-csv" data-id="${escapeAttr(e.id)}">Exportar CSV</button></div>
  <div id="attendeeResults">${people.length?people.map(r=>`<div class="attendee-row"><div class="attendee-person"><span class="attendee-avatar">${escapeHtml(r.name[0])}</span><div><strong>${escapeHtml(r.name)} ${r.demo?'<span class="demo-chip">EXEMPLO</span>':'<span class="real-chip">LOCAL</span>'}</strong><span>${escapeHtml(r.email)}</span></div></div><div class="attendee-controls"><span class="state-chip ${r.checkedIn?'':'wait'}">${r.checkedIn?'✓ Presente':'Pendente'}</span><button class="btn ${r.checkedIn?'btn-outline':'btn-primary'} btn-sm" data-action="checkin" data-id="${escapeAttr(r.id)}">${r.checkedIn?'Desfazer presença':'Confirmar presença'}</button></div></div>`).join(''):`<div class="empty"><h3>Sem resultados</h3><p>Altere o filtro ou a busca.</p></div>`}</div></div>`;
}
function organizerPage() {
  return `<section class="page-wrap container"><div class="breadcrumb"><a href="#inicio">Início</a> / Organizador</div><div class="page-heading"><span class="eyebrow"><span class="eyebrow-dot"></span> CRIE E CONECTE PESSOAS</span><h1>Painel do organizador<span class="heading-dot">.</span></h1><p>Crie eventos, gerencie capacidades e acompanhe presenças.</p></div>
  <div class="demo-alert"><strong>Ambiente demonstrativo:</strong> sem login de administrador, banco de dados ou vagas globais. Os números grandes e os perfis de exemplo são fictícios. As alterações feitas aqui ficam apenas neste navegador.</div>
  <div class="organizer-tabs"><button type="button" class="${state.organizerTab==='resumo'?'active':''}" data-action="organizer-tab" data-tab="resumo">Visão geral</button><button type="button" class="${state.organizerTab==='novo'?'active':''}" data-action="organizer-tab" data-tab="novo">Criar evento</button>${state.organizerTab==='presencas'?'<button type="button" class="active" data-action="organizer-tab" data-tab="presencas">Lista de presença</button>':''}</div>
  ${state.organizerTab==='novo'?newEventForm():state.organizerTab==='presencas'?attendeesPanel():organizerHome()}</section>`;
}
function notFound() { return `<section class="page-wrap container"><div class="empty"><div class="empty-symbol">🧭</div><h3>Página não encontrada</h3><p>Não encontramos o endereço que você abriu.</p><a class="btn btn-primary" href="#inicio">Voltar para o início</a></div></section>`; }
function render(scroll=true) {
  updateAccount();updateNav();const [page,id]=route();
  if(page==='inicio'||!page) app.innerHTML=home();
  else if(page==='eventos'){app.innerHTML=eventsPage();fillEventList();}
  else if(page==='evento') app.innerHTML=getEvent(id)?eventDetail(getEvent(id)):notFound();
  else if(page==='inscricoes') app.innerHTML=registrationsPage();
  else if(page==='confirmacao') app.innerHTML=confirmationPage(id);
  else if(page==='perfil') app.innerHTML=profilePage();
  else if(page==='organizador') app.innerHTML=organizerPage();
  else app.innerHTML=notFound();
  if(scroll) window.scrollTo({top:0,left:0,behavior:'instant'});
  window.unieventsMotion?.refresh?.();
}
function showModal(content) {
  modalRoot.innerHTML=`<div class="modal-backdrop" id="modalBackdrop"><div class="modal" role="dialog" aria-modal="true" aria-labelledby="modalTitle"><button type="button" class="modal-close" data-action="close-modal" aria-label="Fechar">×</button>${content}</div></div>`;
  document.body.style.overflow='hidden';modalRoot.querySelector('input,button')?.focus();
}
function closeModal() {modalRoot.innerHTML='';document.body.style.overflow='';state.pendingSignup=null;}
function loginModal(eventId=null) {
  state.pendingSignup=eventId;
  const event=eventId?getEvent(eventId):null;
  showModal(`<div class="modal-icon login-modal-icon">✦</div><span class="modal-kicker">ÁREA DO PARTICIPANTE · DEMONSTRAÇÃO</span><h2 id="modalTitle">${event?'Entre para garantir a sua vaga':'Que bom ter você de volta!'}</h2><p>${event?`Acesse a conta de demonstração para concluir a inscrição em <strong>${escapeHtml(event.title)}</strong>.`:'Faça login para ver os seus eventos, comprovantes e inscrições já preparadas para apresentação.'}</p>
  <div class="demo-login-help"><span class="demo-login-signal">● PERFIL PREPARADO</span><strong>Uma conta, vários recursos para explorar</strong><small>3 inscrições de exemplo, histórico e painel de presença.</small><button type="button" class="demo-fill" data-action="fill-demo">✦ Preencher acesso de teste</button></div>
  <form id="loginForm" autocomplete="off"><div class="form-row"><label for="demoEmail">E-mail de acesso</label><input class="field" id="demoEmail" name="email" type="email" required maxlength="150" autocomplete="username" placeholder="Digite o e-mail da conta de teste"></div>
  <div class="form-row"><label for="demoPassword">Senha</label><div class="password-field"><input class="field" id="demoPassword" name="password" type="password" required maxlength="100" autocomplete="current-password" placeholder="Digite a senha da demonstração"><button type="button" data-action="toggle-password" aria-label="Mostrar senha" aria-pressed="false">Mostrar</button></div></div>
  <div class="login-validation" id="loginValidation" role="alert" hidden></div>
  <button type="submit" class="btn btn-primary btn-full">${event?'Entrar e confirmar minha vaga':'Entrar na minha área'} <span aria-hidden="true">↗</span></button></form>
  <div class="login-note">🔒 <span><strong>Acesso simulado para apresentação.</strong> Esta senha existe apenas no código do protótipo e não oferece autenticação real. Não utilize dados pessoais sensíveis.</span></div>`);
}
function enroll(eventId) {
  const event=getEvent(eventId); if(!event)return toast('Evento não encontrado.',true);
  if(!currentUser)return loginModal(eventId);
  if(myRegistration(eventId))return navigate(`#confirmacao/${encodeURIComponent(myRegistration(eventId).id)}`);
  if(isPast(event))return toast('Este evento já foi encerrado.',true);
  if(available(event)<=0)return toast('As vagas deste evento se esgotaram.',true);
  const id=(typeof crypto!=='undefined'&&crypto.randomUUID)?crypto.randomUUID():`r-${Date.now()}-${Math.random().toString(36).slice(2)}`;
  const entry={id,eventId,name:currentUser.name,email:normalizeEmail(currentUser.email),checkedIn:false,createdAt:new Date().toISOString()};
  const previous=registrations;
  registrations=[...registrations,entry];
  if(!save(STORAGE.registrations,registrations)){registrations=previous;return;}
  toast('Inscrição confirmada! Seu comprovante está disponível.');
  window.unieventsMotion?.celebrate?.();
  navigate(`#confirmacao/${encodeURIComponent(entry.id)}`);
}
function cancelSignup(id) {
  const r=registrations.find(x=>x.id===id);
  if(!r||!currentUser||normalizeEmail(r.email)!==normalizeEmail(currentUser.email))return toast('Inscrição não encontrada para o perfil.',true);
  if(!window.confirm('Deseja realmente cancelar esta inscrição?'))return;
  const copy=registrations;registrations=registrations.filter(x=>x.id!==id);
  if(!save(STORAGE.registrations,registrations)){registrations=copy;return;}
  toast('Inscrição cancelada. Sua vaga foi liberada neste navegador.');render(false);
}
function printCertificate(id) {
  const r=registrations.find(x=>x.id===id&&normalizeEmail(x.email)===normalizeEmail(currentUser?.email)&&x.checkedIn);
  if(!r)return toast('Certificado indisponível.',true);
  const e=getEvent(r.eventId);if(!e)return;
  const popup=window.open('','_blank');if(!popup)return toast('Habilite pop-ups para imprimir.',true);
  popup.document.write(`<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>Certificado demonstrativo</title><style>body{font-family:Arial,sans-serif;text-align:center;color:#25265f;padding:70px 45px;border:12px double #7565e6;min-height:390px}h1{font-size:37px}p{font-size:18px;line-height:1.7}strong{color:#5d53d1}.note{margin-top:42px;font-size:12px;color:#777}</style></head><body><h1>✦ Certificado de participação</h1><p>Certificamos, para fins de demonstração, que</p><h2>${escapeHtml(r.name)}</h2><p>participou do evento <strong>${escapeHtml(e.title)}</strong>, realizado em ${prettyDate(e.date)}.</p><p class="note">UniEventos · Certificado fictício · Sem validade acadêmica.</p></body></html>`);
  popup.document.close();popup.focus();popup.print();
}
function createEvent(form) {
  const formData=new FormData(form);
  const title=clean(formData.get('title'),100),category=clean(formData.get('category'),30),format=clean(formData.get('format'),20),date=clean(formData.get('date'),10),time=clean(formData.get('time'),5),place=clean(formData.get('place'),90),host=clean(formData.get('host'),90),summary=clean(formData.get('summary'),180),description=clean(formData.get('description'),1200),seats=Number(formData.get('seats'));
  if(title.length<5||!CATEGORY_INFO[category]||!['Presencial','Online','Híbrido'].includes(format)||!/^\d{4}-\d{2}-\d{2}$/.test(date)||date<today()||!/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(time)||!place||!host||!summary||!description||!Number.isSafeInteger(seats)||seats<1||seats>100000)return toast('Confira os campos, a data e a quantidade de vagas.',true);
  const colors={Tecnologia:['#28225f','#6c5bea'],Carreiras:['#ef795e','#f8b46b'],Workshops:['#24688a','#39b5b0'],Acadêmico:['#185e77','#5ca1b5'],Cultura:['#a73e84','#e875ac'],Esportes:['#147d76','#51c9b3']}[category];
  const event={id:`${slugify(title).slice(0,42)}-${Date.now()}`,title,category,format,date,time,place,host,summary,description,seats,emoji:CATEGORY_INFO[category].emoji,coverLabel:category,colors,topics:['Aprendizado e experiências práticas','Conexão com a comunidade universitária','Atividades relacionadas ao tema'],custom:true};
  const old=customEvents;customEvents=[...customEvents,event];
  if(!save(STORAGE.events,customEvents)){customEvents=old;return;}
  toast('Evento publicado nesta demonstração!');state.organizerTab='resumo';render(false);
}
function editCapacity(id) {
  const event=getEvent(id);if(!event)return;
  const lower=occupied(event);
  showModal(`<div class="modal-icon">🎟️</div><h2 id="modalTitle">Editar quantidade de vagas</h2><p><strong>${escapeHtml(event.title)}</strong></p><p>Atualmente: <strong>${prettyNumber(event.seats)} vagas</strong> · Ocupadas (simulação + locais): ${prettyNumber(lower)}.</p><form id="capacityForm" data-id="${escapeAttr(id)}"><div class="form-row"><label for="newCapacity">Nova capacidade</label><input id="newCapacity" name="capacity" class="field" type="number" min="${lower}" max="100000" value="${event.seats}" required><small class="field-note">A capacidade não pode ficar abaixo das inscrições demonstrativas e locais.</small></div><button class="btn btn-primary btn-full" type="submit">Salvar capacidade →</button></form>`);
}
function exportCSV(id) {
  const e=getEvent(id);if(!e)return;
  const people=[...realRegistrations(id).map(x=>({...x,demo:false})),...samplePeople(e)];
  const rows=[['Nome','E-mail','Presença','Tipo'],...people.map(r=>[r.name,r.email,r.checkedIn?'Presente':'Pendente',r.demo?'Exemplo fictício':'Inscrição local'])];
  const content='\uFEFF'+rows.map(row=>row.map(cell=>`"${String(cell).replace(/"/g,'""')}"`).join(';')).join('\r\n');
  const blob=new Blob([content],{type:'text/csv;charset=utf-8'});
  const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=`participantes-${slugify(e.title)}.csv`;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
  toast('CSV gerado com participantes fictícios e registros locais.');
}
async function copyCode(val) {
  try { if(navigator.clipboard?.writeText) await navigator.clipboard.writeText(val); else {const field=document.createElement('textarea');field.value=val;document.body.append(field);field.select();document.execCommand('copy');field.remove();} toast('Código de confirmação copiado!'); }
  catch { toast('Não foi possível copiar automaticamente.',true); }
}
function handleAction(el) {
  const action=el.dataset.action,id=el.dataset.id;
  switch(action) {
    case 'category':state.category=el.dataset.category;state.search='';state.format='Todos';state.period='Todos';navigate('#eventos');break;
    case 'clear-filters':state.category='Todos';state.search='';state.format='Todos';state.period='Todos';render(false);document.getElementById('searchEvents')?.focus();break;
    case 'signup':enroll(id);break;
    case 'login':loginModal();break;
    case 'fill-demo': {
      const email=modalRoot.querySelector('#demoEmail'),password=modalRoot.querySelector('#demoPassword');
      if(email&&password){email.value=DEMO_ACCOUNT.email;password.value=DEMO_ACCOUNT.password;const error=modalRoot.querySelector('#loginValidation');if(error)error.hidden=true;password.focus();toast('Acesso de teste preenchido. Clique em Entrar!');}
      break;
    }
    case 'toggle-password': {
      const password=modalRoot.querySelector('#demoPassword');if(!password)return;
      const shown=password.type==='password';password.type=shown?'text':'password';el.textContent=shown?'Ocultar':'Mostrar';el.setAttribute('aria-label',shown?'Ocultar senha':'Mostrar senha');el.setAttribute('aria-pressed',String(shown));break;
    }
    case 'logout':currentUser=null;if(save(STORAGE.user,null)){toast('Você saiu do perfil de demonstração.');navigate('#inicio');}break;
    case 'switch-profile':loginModal();break;
    case 'close-modal':closeModal();break;
    case 'cancel':cancelSignup(id);break;
    case 'certificate':printCertificate(id);break;
    case 'print-confirmation':window.print();break;
    case 'copy-code':copyCode(el.dataset.code);break;
    case 'organizer-tab':state.organizerTab=el.dataset.tab;render(false);break;
    case 'organizer-new':state.organizerTab='novo';render(false);break;
    case 'organizer-attendees':state.selectedOrganizerEvent=id;state.organizerTab='presencas';state.attendeeSearch='';state.attendeeFilter='Todos';render(false);break;
    case 'organizer-back':state.organizerTab='resumo';render(false);break;
    case 'edit-capacity':editCapacity(id);break;
    case 'export-csv':exportCSV(id);break;
    case 'checkin': {
      if(id.startsWith('sample-')){sampleAttendance[id]=!sampleAttendance[id];if(!save(STORAGE.attendance,sampleAttendance))sampleAttendance[id]=!sampleAttendance[id];}
      else {const r=registrations.find(x=>x.id===id);if(!r)return;const newArr=registrations.map(x=>x.id===id?{...x,checkedIn:!x.checkedIn}:x);if(!save(STORAGE.registrations,newArr))return;registrations=newArr;}
      toast('Status de presença atualizado.');render(false);break;
    }
    case 'delete-event': {
      const e=customEvents.find(x=>x.id===id);if(!e)return;
      if(!window.confirm(`Excluir o evento "${e.title}" e suas inscrições locais?`))return;
      const events2=customEvents.filter(x=>x.id!==id),regs2=registrations.filter(r=>r.eventId!==id);
      if(!save(STORAGE.events,events2))return;
      if(!save(STORAGE.registrations,regs2)){save(STORAGE.events,customEvents);return;}
      customEvents=events2;registrations=regs2;toast('Evento removido.');render(false);break;
    }
  }
}

// Event delegation protects forms/cards after client-side navigation.
document.addEventListener('click',event=>{
  const action=event.target.closest('[data-action]');
  if(action){event.preventDefault();handleAction(action);}
  if(event.target.id==='modalBackdrop')closeModal();
});
document.addEventListener('submit',event=>{
  if(event.target.id==='loginForm') {
    event.preventDefault();
    const form=new FormData(event.target),email=normalizeEmail(form.get('email')),password=String(form.get('password')||'');
    if(email!==DEMO_ACCOUNT.email||password!==DEMO_ACCOUNT.password){
      const error=modalRoot.querySelector('#loginValidation');
      if(error){error.textContent='E-mail ou senha incorretos. Use a conta de demonstração informada no guia ou o botão de preenchimento.';error.hidden=false;}
      toast('Não foi possível entrar. Confira os dados da conta de teste.',true);
      return;
    }
    const signup=state.pendingSignup,old=currentUser;
    currentUser={name:DEMO_ACCOUNT.name,email:DEMO_ACCOUNT.email,role:'participante',demo:true};
    if(!save(STORAGE.user,currentUser)){currentUser=old;return;}
    seedDemoDashboard();closeModal();updateAccount();
    toast(`Acesso liberado. Bem-vindo, ${DEMO_ACCOUNT.name.split(' ')[0]}!`);
    if(signup)enroll(signup);else navigate('#inscricoes');
  }
  if(event.target.id==='newEventForm'){event.preventDefault();if(event.target.reportValidity())createEvent(event.target);}
  if(event.target.id==='capacityForm') {
    event.preventDefault();const id=event.target.dataset.id,e=getEvent(id),seats=Number(new FormData(event.target).get('capacity'));
    if(!e||!Number.isSafeInteger(seats)||seats<occupied(e)||seats>100000)return toast('Informe uma capacidade válida, respeitando a ocupação.',true);
    const previous=capacityOverrides[id];capacityOverrides[id]=seats;
    if(!save(STORAGE.overrides,capacityOverrides)){if(previous===undefined)delete capacityOverrides[id];else capacityOverrides[id]=previous;return;}
    closeModal();toast('Quantidade de vagas atualizada!');render(false);
  }
});
document.addEventListener('input',event=>{
  if(event.target.id==='searchEvents'){state.search=event.target.value;fillEventList();}
  if(event.target.id==='attendeeSearch') {state.attendeeSearch=event.target.value;const start=event.target.selectionStart;const end=event.target.selectionEnd;const el=document.getElementById('attendeeResults');if(!el)return;const dummy=document.createElement('div');dummy.innerHTML=attendeesPanel();el.innerHTML=dummy.querySelector('#attendeeResults').innerHTML;event.target.focus();event.target.setSelectionRange(start,end);}
});
document.addEventListener('change',event=>{
  if(event.target.id==='filterCategory'){state.category=event.target.value;fillEventList();}
  if(event.target.id==='filterFormat'){state.format=event.target.value;fillEventList();}
  if(event.target.id==='filterPeriod'){state.period=event.target.value;fillEventList();}
  if(event.target.id==='attendeeFilter'){state.attendeeFilter=event.target.value;render(false);}
});
document.getElementById('accountButton').addEventListener('click',()=>currentUser?navigate('#perfil'):loginModal());
document.getElementById('menuButton').addEventListener('click',()=>{
  const nav=document.getElementById('mobileNav');nav.hidden=!nav.hidden;
  document.getElementById('menuButton').setAttribute('aria-expanded',String(!nav.hidden));
});
document.getElementById('mobileNav').addEventListener('click',event=>{if(event.target.closest('a'))closeMobileMenu();});
document.addEventListener('keydown',event=>{
  if(event.key==='Escape'&&modalRoot.innerHTML)closeModal();
  if(event.key==='Tab'&&modalRoot.innerHTML){const focusable=[...modalRoot.querySelectorAll('button:not(:disabled), input:not(:disabled), select, textarea, a[href]')];if(focusable.length){const first=focusable[0],last=focusable[focusable.length-1];if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}}}
});
window.addEventListener('hashchange',()=>render(true));
window.addEventListener('storage',(event)=>{
  if(Object.values(STORAGE).includes(event.key)){
    currentUser=read(STORAGE.user,null);customEvents=read(STORAGE.events,[]);registrations=read(STORAGE.registrations,[]);capacityOverrides=read(STORAGE.overrides,{});sampleAttendance=read(STORAGE.attendance,{});
    if(!Array.isArray(customEvents))customEvents=[];if(!Array.isArray(registrations))registrations=[];
    if(!capacityOverrides || typeof capacityOverrides!=='object')capacityOverrides={};
    if(!sampleAttendance || typeof sampleAttendance!=='object')sampleAttendance={};
    render(false);
  }
});
render();
